let initialForm = document.getElementById('initialForm');
let initialFormContainer = document.getElementById('initialFormContainer');

initialForm.addEventListener('submit',function(event) {
    event.preventDefault();

    let firstName = document.getElementById('firstName').value;

    let newFormContainer = document.createElement('div');
    newFormContainer.className ='new-form-container';

    //new form
newFormContainer.innerHTML =`
    <h2>Welcome, ${firstName}!</h2>
    <p>Please update your details to complete the form</p>
        
    <form id="secondaryForm">

    <label for ="email">Email</label><br/>
    <input type="email" id ="email" required><br/>

    <label for ="password">Password</label><br/>
    <input type="password" id ="password" required><br/>

    <button type="submit">Complete Sign Up Form</button>

</form>
`;
document.body.prepend(newFormContainer);

initialFormContainer.style.display ='none';

 //adding to newly created form
 let secondaryForm=document.getElementById('secondaryForm');
 secondaryForm.addEventListener('submit',function(e) {

    e.preventDefault();

    alert('Congralutions! Your account is created');
 });
 });

 let toggleButton =document.getElementById('toggleDarkMode');

 if(toggleButton){
    toggleButton.addEventListener('click',function(){
        document.body.classList.toggle('darkmode');

    if(document.body.classList.contains('darkmode')){
            toggleButton.textContent = 'Switch to light Mode';
        }else{
                    toggleButton.textcontent='Switch to Dark Mode';
                }

    });
 }
